package projects;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class HotelManagement2 {
	
   public static final String url="jdbc:mysql://localhost:3306/HotelManagement?useSSL=false";
	
	public static void main(String[] args) throws ClassNotFoundException   {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		 int attempt=3;
		
		//String url="jdbc:mysql://localhost:3306/HotelManagement";
		try(Connection con=DriverManager.getConnection(url,"root","3600")){
			int loginattempt=0;
		
		createTable(con);
		while(loginattempt<attempt) {
		
			if(adminlogin()) {
		// TODO Auto-generated method stub
	   System.out.println("---------------------------------------");
	   System.out.println("Hotel Management System");
	   System.out.println("* HOTEL ADMINSTRATE *");
	   System.out.println("*DINESH*MATHAN*AAKARSH*");
	  
	   System.out.println("---------------------------------------");
       while(true) {
       System.out.println("Menu Detilas(1-5):");
       System.out.println("1.CREATE ");
       System.out.println("2.View");
       System.out.println("3.UPDATE ");
       System.out.println("4.Delete ");
       System.out.println("5.Exit");
       System.out.println("Enter the Menu(1-5): ");
       Scanner sc=new Scanner(System.in);
       int ch=sc.nextInt();
       switch(ch) {
       case 1:
    	   System.out.println("BOOK  Rooms for Registration ");
    		bookrooms(con);   		
    	   break;
       case 2:
    	   System.out.println("VIEW for register details ");
    	   viewforregrooms(con);
    	   break;
       case 3:
    	   System.out.println("UPDATE for Account ");
    	   upadtefordetails(con);
    	   break;
       case 4:
    	   System.out.println("DELETE for Account");
    	   deleteforaccout(con);
    	   break;       
       case 5:
    	  // return;
    	   System.out.println("Thank you welcome");
    	   System.exit(0);
      default:
    	  System.out.println("Only enter for (1-5) re for menu");
    	  break;
    	   
       }
      // System.out.println("THank you  Welcome");
       System.out.println("---------------------------------"); 
       
      }
	}
			else {
				loginattempt++;
				System.out.println("Invalid Admin Login Attempts remaining:"+(attempt-loginattempt));
			}
		}
		if(loginattempt==attempt) {
			System.out.println("MAXIMUM LOGIN ATTEMPTS SYSTEM EXIT");
			System.out.println("Thank you");
			System.exit(0);
		}
      } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
		
		
   }
   


	private static boolean adminlogin() {
		// TODO Auto-generated method stub
		System.out.println("Hotel Management System");
		Scanner sc= new Scanner(System.in);
		System.out.println("Admin Login:");
		System.out.print("User Name:");
		String s=sc.next();
		System.out.print("Password:");
		String t=sc.next();
		return ((s.equals("admin"))&&(t.equals("admin123")));
		
		
	}



	private static void createTable(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		String createTablesql ="create table if not exists guests("+ "id  int primary key auto_increment,"+"Name varchar(100), "+ "ContactNo varchar(20),"+"Address varchar(120) ,"+"RoomType varchar(10),"+" FoodService varchar(10),"+"StayDays int , "+"Numofperson int ,"+"Amount int" +")";
        try (Statement stmt=con.createStatement()){
        	stmt.executeUpdate(createTablesql);
        	
		}    
	}
	private static void bookrooms(Connection con) throws SQLException {
		// TODo Auto-generated method stub
	 
		Scanner s1=new Scanner(System.in); 	
	     System.out.print("Enter your name: ");
	     String name=s1.next();
	     System.out.print("Enter your Contact No: ");
	     String contactno=s1.next();
	     System.out.print("Enter your Addres: ");
	     String add=s1.next();	      
	     System.out.print("Rooms for Available (AC/NON-AC): ");	     
	     String roomtype=s1.next();
	     System.out.print("Restaurant food for available (YES/NO): ");
	     String foodservice=s1.next();
	     System.out.print("How Many days room Booking: ");
	     int staydays=s1.nextInt();
	     System.out.print("Number of person: ");
	     int np=s1.nextInt();    
	     int a=np*staydays*500;
	     int b=np*((staydays*500)+(staydays*400));
	     int c=np*(staydays*800);
	     int d=np*((staydays*800)+(staydays*400));
	     String insertSql="insert into guests(Name,ContactNo,Address,RoomType,FoodService,StayDays,Numofperson,Amount)"+"values(?,?,?,?,?,?,?,?)";
	     PreparedStatement pst;
		try {
			pst = con.prepareStatement(insertSql);
		
	     pst.setString(1, name);
	     pst.setString(2, contactno);
	     pst.setString(3, add);
	     pst.setString(4, roomtype);
	     pst.setString(5, foodservice);
	     pst.setInt(6, staydays);
	     pst.setInt(7, np);
	     
	     
   
	     if(roomtype.equalsIgnoreCase("NON-AC")) {
	    	 System.out.println("NON-AC Room for 1 day 500");
	    	 System.out.println("Food per day 1(head):400");
	    	 if(foodservice.equalsIgnoreCase("NO")) {		 
	        	  pst.setInt(8, a);
	    	      System.out.println("rent amount(room only): "+a);
	    	  }
	    	 else {
	    		 pst.setInt(8, b);
	    		 System.out.println(" total amount(food +room): "+b);
	    	 }
	    	System.out.println(name+ "  room Booking confirmed");
	     }
	     else if(roomtype.equalsIgnoreCase("AC")) {
	    	 System.out.println("AC Room for 1 day 800");
	    	 System.out.println("Food per day 1(head):400");
	    	 if(foodservice.equalsIgnoreCase("NO")) {			 
	    		  pst.setInt(8, c);
	    	      System.out.println("total amount(room only): "+c);
	    	  } 
	    	 else {
	    		 pst.setInt(8, d);
	    		 System.out.println(" total amount(food +room): "+d);
	    	 }
	    	 System.out.println(name+"  room Booking confirmed");
	    	 int i=pst.executeUpdate();
	    	 System.out.println(i+"Inserted Successfully");
	    }
	     else  {
	    		System.out.println("please enter crt details you enter not values");
	    	 }
	   // con.close();
     	//pst.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
	private static void viewforregrooms(Connection con) {
		// TODO Auto-generated method stub
		String SelectSql="select*from guests";
		try(Statement stmt=con.createStatement();
				ResultSet rs=stmt.executeQuery(SelectSql)){
			System.out.println("RoomID     Name            ContactNo        Address     Room(AC/NON-AC)        FOod(Yes/No)      StayDays      NumberofPersons       Amount  ");

			while(rs.next()) {
				System.out.println(rs.getInt(1)+"          "+rs.getString(2)+"        " +rs.getString(3)+"         "+rs.getString(4)+"      " +rs.getString(5)+"                "+rs.getString(6)+"                     "+rs.getInt(7)+"                  "+rs.getInt(8)+"             "+rs.getInt(9)+"    ");
              
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void upadtefordetails(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sm=new Scanner(System.in);
		
		System.out.print("Enter your Phone no: ");
	    String phoneno =sm.next();
	   
	    	 if(isContactNo(con,phoneno)) { 
	    		System.out.println("Enter Your Update Details: ");
	    		System.out.print("Enter your name:");
	    		String name=sm.next();
	    		 System.out.print("Enter your Addres: ");
	    	     String add=sm.next(); 
	    	     System.out.print("Rooms for Available (AC/NON-AC): ");
	    	     String room=sm.next();
	    	     System.out.print("Restaurant food for available (YES/NO): ");
	    	     String food=sm.next();
	    	     System.out.print("How Many days room Bokking: ");
	    	     int day=sm.nextInt(); 
	    	     System.out.print("How Many days number of person: ");
	    	     int nop=sm.nextInt(); 
	    	     
	    	    String updateSql="update guests set Name=?,Address=?,RoomType=?,FoodService=?,StayDays=?,Numofperson=?,Amount=? where ContactNo=?";
                try(PreparedStatement pst=con.prepareStatement(updateSql)){
                pst.setString(1, name);
                pst.setString(2, add);
                pst.setString(3, room);
                pst.setString(4, food);
                pst.setInt(5, day);
                pst.setInt(6, nop);
                pst.setString(8, phoneno);
	    	    int a=nop*day*500;
	    	    int b=nop*((day*500)+(day*400));
	    	    int c=nop*day*800;
	    	    int d=nop*((day*800)+(day*400));

	    	     if(room.equalsIgnoreCase("NON-AC")) {
	    	    	 System.out.println("NON-AC Room for 1 day 500");
	    	    	 System.out.println("Food per day 1(head):400");
	    	    	 if(food.equalsIgnoreCase("NO")) {		 
	    	    		  pst.setInt(7, a);
	    	    	      System.out.println("rent amount(room only): "+a);
	    	    	  }
	    	    	 else {
	    	    		 pst.setInt(7, b);
	    	    		 System.out.println(" total amount(food +room): "+b);
	    	    	 }
	    	    	System.out.println(name+ "  your Details for updated");
	    	     }
	    	     else if(room.equalsIgnoreCase("AC")) {
	    	    	 System.out.println("AC Room for 1 day 800");
	    	    	 System.out.println("Food per day 1(head):400");
	    	    	 if(food.equalsIgnoreCase("NO")) {	
	    	    		 pst.setInt(7, c);
	    	    	      System.out.println("total amount(room only): "+c);
	    	    	  } 
	    	    	 else {
	    	    		 pst.setInt(7, d);
	    	    		 System.out.println(" total amount(food +room): "+d);
	    	    	 }
	    	    	 System.out.println(name+"  your details for updated");
	    	     }
	    	    	 
	    	     else{
	    	    	System.out.println(name+"your not updated for this time please check");	 
	    	    	 }
	    	    pst.executeUpdate();
	    	    System.out.println("updated succeessfully");
	    	     return;
	    	
	    	
	    	 }
                  
	    
	  }
	    	
	  System.out.println("!Sorry Not a valid fo phone number!\n!Please check number!");
	              		
}

	private static boolean isContactNo(Connection con, String phoneno) throws SQLException {
		// TODO Auto-generated method stub
	    String Selectsql="select count(*) from guests where ContactNo=? ";
	    try(PreparedStatement pst=con.prepareStatement(Selectsql)){
	    	pst.setString(1,phoneno);
	    	ResultSet rs=pst.executeQuery();
	    	rs.next();
	    	return rs.getInt(1)>0;
	    }
	
	}



	private static void deleteforaccout(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		Scanner sm=new Scanner(System.in);
		System.out.print("Enter your contact number to Delete: ");
		String contact_no=sm.next();
		   
		if(isContactNo(con,contact_no)) { //true
		 String deleteSql="delete from guests where ContactNo=?";
		 try(PreparedStatement pst=con.prepareStatement(deleteSql)){
			 pst.setString(1, contact_no);
			 int rows=pst.executeUpdate();
			 if(rows>0) {
				 System.out.println("customer deleted successfully");
			 }
			 else {
				 System.out.println("No found on customers");
			 }
	
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}		
		else {
			System.out.println("NOt found for deletion");
		}
	}




	

}