/**
 * 
 */
/**
 * 
 */
module hms_project {
	requires java.sql;
}